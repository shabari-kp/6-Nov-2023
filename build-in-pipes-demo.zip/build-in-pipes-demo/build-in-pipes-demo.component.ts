import { Component } from '@angular/core';

@Component({
  selector: 'app-build-in-pipes-demo',
  templateUrl: './build-in-pipes-demo.component.html',
  styleUrls: ['./build-in-pipes-demo.component.css']
})
export class BuildInPipesDemoComponent {
firstname:string="alex";
lastname:string="PAUL";

msg:string="this is bad";
today: number = Date.now(); //js object

xyz:number=12.3456789;


//object defined in ts
rows={
username:123,
password:456,
age:44,
sal:45674
}


}
