import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildInPipesDemoComponent } from './build-in-pipes-demo.component';

describe('BuildInPipesDemoComponent', () => {
  let component: BuildInPipesDemoComponent;
  let fixture: ComponentFixture<BuildInPipesDemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BuildInPipesDemoComponent]
    });
    fixture = TestBed.createComponent(BuildInPipesDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
